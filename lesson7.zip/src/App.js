import './App.css';
import TodosPage from "./pages/todosPage/TodosPage";

function App() {
    return (
        <div className="App">
            <TodosPage/>
        </div>
    );
}

export default App;






